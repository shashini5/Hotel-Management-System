
package Model;



/**
 *
 * @author Dimuth
 */
public class Customer {
    private int cus_ID;
    private String cus_Name;
    private String cus_Email;
    private String cus_Address;
    private String cus_ContactNum;
    private String cus_Gender;

   
    public Customer (int id,String name,String email,String address,String contactNo, String gender ){
        this.cus_ID = id;
        this.cus_Name = name;
        this.cus_Email = email;
        this.cus_Address = address;
        this.cus_ContactNum = contactNo;
        this.cus_Gender = gender;
    }
    
     public int getCus_ID() {
        return cus_ID;
    }

    public String getCus_Name() {
        return cus_Name;
    }

    public String getCus_Email() {
        return cus_Email;
    }

    public String getCus_Address() {
        return cus_Address;
    }

    public String getCus_ContactNum() {
        return cus_ContactNum;
    }

    public String getCus_Gender() {
        return cus_Gender;
    }
    
    
}
