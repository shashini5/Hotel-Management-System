
package Controller;

import Model.Customer;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

/**
 *
 * @author Dimuth
 */
public class SearchCustomer {
    public ArrayList <Customer> ListCustomers (String ValToSearch){
        ArrayList<Customer> customerList = new ArrayList<Customer>();
        Statement st;
        ResultSet rs;
        
        try{
            DbConnection dbc = new DbConnection();
            Connection con = dbc.getConnection();
            st = con.createStatement();
            String searchQuery = "SELECT * FROM `customer` WHERE CONCAT(`Customer_ID`, `Customer_Name`, `Customer_Email`, `Address`, `Contact_Number`, `Gender`) LIKE '%"+ValToSearch+"%'";
            rs = st.executeQuery(searchQuery);
            
            Customer customer;
            
            while(rs.next()){
                customer = new Customer(
                        rs.getInt("Customer_ID"),
                        rs.getString("Customer_Name"),
                        rs.getString("Customer_Email"),
                        rs.getString("Address"),
                        rs.getString("Contact_Number"),
                        rs.getString("Gender")
                );
                customerList.add(customer);
                
            }
            
        }catch(Exception ex){
            System.out.println(ex.getMessage());
        }
        return customerList;
    }
    
}
