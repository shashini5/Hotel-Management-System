-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 07, 2017 at 07:20 PM
-- Server version: 10.1.21-MariaDB
-- PHP Version: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `winhe_it`
--

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `Customer_ID` int(11) NOT NULL,
  `Customer_Name` varchar(20) NOT NULL,
  `Customer_Email` varchar(25) DEFAULT NULL,
  `Address` char(30) NOT NULL,
  `Contact_Number` char(10) NOT NULL,
  `Date_Of_Birth` date DEFAULT NULL,
  `Gender` char(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`Customer_ID`, `Customer_Name`, `Customer_Email`, `Address`, `Contact_Number`, `Date_Of_Birth`, `Gender`) VALUES
(5, 'Nimal Perera', 'nimal@gmail.com', '04, Nawala rd, Nugegoda', '776543056', '2017-12-20', 'Male'),
(8, 'Sandamali Fonseka', 'sanda@yahoo.com', '6/A Maharagama rd Nawinna', '0774527637', '0000-00-00', 'Female'),
(16, 'Neil Soyza', 'neil@gamail.com', '28 malabe rd kadawatha', '0112834848', '0000-00-00', 'Male');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `Product_ID` int(11) NOT NULL,
  `Product_Name` varchar(20) NOT NULL,
  `Product_Description` char(40) DEFAULT NULL,
  `Purchase_Price` decimal(10,0) NOT NULL,
  `Selling_Price` decimal(10,0) NOT NULL,
  `Quantity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`Product_ID`, `Product_Name`, `Product_Description`, `Purchase_Price`, `Selling_Price`, `Quantity`) VALUES
(1, 'Dell Latitiude E62', 'Laptop', '95000', '120000', 5),
(2, 'Logitech M225', 'Mouse', '2800', '3500', 10),
(6, 'Kingston 8GB pendriv', 'Pendrive', '1400', '2000', 15);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`Customer_ID`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`Product_ID`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
