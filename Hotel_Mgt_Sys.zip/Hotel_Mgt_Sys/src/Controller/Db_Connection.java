/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
//import java.sql.Statement;

/**
 *
 * @author Dimuth
 */
public class Db_Connection {
    public static Connection getConnection(){
        
        Connection conn = null;
        try{
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/hotelmgt","root","");
//            System.out.println("Connected");
//            Statement stmt = (Statement) conn.createStatement();
//            String fName = "Admin";
//            String lName = "Admin";
//            String type = "ad001";
//            String nic = "3640341v";
//            String contactNo = "0714602518";
//            String gender = "M";
//            String insert = "INSERT INTO `employee`(`emp_FName`, `emp_LName`, `emp_Type`, `emp_NIC`, `emp_Gender`,`emp_ContactNo`) VALUES ('"+fName+"','"+lName+"','"+type+"','"+nic+"','"+gender+"','"+contactNo+"')";
//            stmt.execute(insert);
            
                    
        }catch(SQLException ex){
            System.out.println(ex.getMessage());
        }
        return conn;
    }
    
    public static void main(String[] args){
        Db_Connection db = new Db_Connection();
        db.getConnection();
    }
    
    
}
