/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;
import Model.UserLogin;
import View.Admin_Panel;
import View.Login;
import View.Reception_Resv;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
/**
 *
 * @author Dimuth
 */
public class LoginController {
    
    public int LoginController(UserLogin login){
        
    try{
        Connection conn = null;
        PreparedStatement ps;
        
        String userName = login.getUsername();
        char[] password = login.getPassword();
        
        conn = Db_Connection.getConnection();
        ps = conn.prepareStatement("SELECT * FROM userprofile WHERE userName = ? AND passWord = ?");

            ps.setString(1, userName);
            ps.setString(2, String.valueOf(password));
            ResultSet rs = ps.executeQuery();
            
            if(rs.next()){
                    String userType = rs.getString("emp_Type");
                    if(userType.equals("ADMIN")){
                        return 1;
                    }else if(userType.equals("RCEP")){
                        return 2;
                    }else if(userType.equals("REST")){
                        return 3;
                    }
            }else{
                conn.close();
                return 0;
            }
        } catch (SQLException ex){
            Logger.getLogger(Login.class.getName()).log(Level.SEVERE, null, ex);
        }
    
        return 0;
    }   
}
