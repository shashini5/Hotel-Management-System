package Model;


public class Staff {
    private int id;
    private String name;
    private String nic;
    private String gender;
    private String address;
    private int age;
    private String category;
    private byte[] photo;
    
    public Staff(int pid, String pname, String pnic, String pgender, String paddress, int page, String pcategory, byte[]pimg){
        this.id= pid;
        this.name= pname;
        this.nic= pnic;
        this.gender= pgender;
        this.address=paddress;
        this.age= page;
        this.category= pcategory;
        this.photo= pimg;
    }
  public int getid(){
      return id;
  }  
  public String getName(){
      return name;
  } 
  public String getNIC(){
      return nic;
  }
  public String getGender(){
      return gender;
  }
  public String getAddress(){
      return address;
  }
  public int getAge(){
      return age;
  }
  public String getCategory(){
      return category;
  }
  public byte[] getImage(){
      return photo;
  }
  
}
