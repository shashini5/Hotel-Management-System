/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;
import View.Login;

/**
 *
 * @author Dimuth
 */
public class UserLogin {
     private String username;
     private char[] password;

    public UserLogin(String username, char[] password) {
        this.username = username;
        this.password = password;
    }

    public String getUsername() {
        return username;
    }

    public char[] getPassword() {
        return password;
    }
    
     
    
    
}
